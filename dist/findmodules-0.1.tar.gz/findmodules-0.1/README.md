# Automatic Module Discovery
A module called ```findmodules``` which facilitates use of the Moodle VPLs by searching the current working directory for files which may be student work.

## Installation
1. Download this repository.
2. Navigate (i.e. ```cd```) into the top-level folder of the repository. You should see a file called ```pyproject.toml```.
3. Run ```python3 -m pip install .``` to install the program. Note that you may want to install this in "editable" mode by adding ```-e``` or ```--editable```:
```python3 -m pip -e install .```

__Note:__ To use this with Moodle VPLs, you will need to upload this project's file ```findmodules.py``` along with the solution, test cases, and any other files. At time of writing, ```findmodules``` is NOT in the Python Package Index.

## Build Process
1. Navigate to top level directory.
2. Install ```build``` if necessary:
   
   ```python3 -m pip install --upgrade build```

3. Build ```findmodules```:

   ```python3 -m build```

4. Install ```findmodules```:

   ```python3 -m pip install .```

5. Check that the module is importable:

   ```python3 -m findmodules```

   You should see: ```['__init__.py', 'findmodules.py']```

## Notes:
- The directory structure is minimal. I had difficulty ensuring that the *package* was 
importable with ```import findmodules```rather than with ```from findmodules import findmodules``` 
or ```findmodules.findmodules```.
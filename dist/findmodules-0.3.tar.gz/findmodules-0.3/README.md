# Automatic Module Discovery
A module called ```findmodules``` which facilitates use of the Moodle VPLs by searching the current working directory for files which may be student work.

### Example Usages
1. Minimal Use. Find student's file, and run tests.
```
import os.path
import findmodules

lab = findmodules.import_student_module(os.path.dirname(__file__))
```

2. More involved: compare a student's code against known good code which serves as an answer key.
```
import os.path
import importlib
import findmodules
MODULE_TO_TEST = "fairground_ride_key"     # name of key file, which is ignored.

key = importlib.import_module(MODULE_TO_TEST)
lab = findmodules.import_student_module(os.path.dirname(__file__), ignore_when_testing=[MODULE_TO_TEST])
```

## Installation
1. Download this repository.
2. Navigate (i.e. ```cd```) into the top-level folder of the repository. You should see a file called ```pyproject.toml```.
3. In a terminal, run ```python3 -m pip install .``` to install the program. You may want to install this in "editable" mode by adding ```-e``` or ```--editable```:
```python3 -m pip -e install .```

__Note:__ To use this with Moodle VPLs, you will need to upload this project's file ```findmodules.py``` along with the solution, test cases, and any other files. At time of writing, ```findmodules``` is NOT in the Python Package Index.

## Build Process
You you should not need to do this more than once, if at all.
1. Navigate to top level directory.
2. Install ```build``` if necessary:
   
   ```python3 -m pip install --upgrade build```

3. Build ```findmodules```:

   ```python3 -m build```

4. Install ```findmodules```:

   ```python3 -m pip -e install .```

5. Check that the module is importable:

   ```cd ../``` Get out of the directory where the module actually lives. That'll cheat on the importing test.

   ```python3 -m findmodules```

   You should see a list of all the python modules you have in the directory where the command was run.

## Notes:
- The directory structure is minimal. I had difficulty ensuring that the *package* was importable with ```import findmodules```rather than with ```from findmodules import findmodules``` or ```findmodules.findmodules```.
from distutils.core import setup

setup(name='findmodules',
      version='0.3',
      description='A package which facilitates use of the Moodle VPLs by searching the current working directory for other python files.',
      author='William Bailey',
      author_email='william.bailey@centre.edu',
      url='https://github.com/wba234/baileycs1',
      packages=[],
     )